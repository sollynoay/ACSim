#  sonarRT_plugin.py
#
#  Blender add-on for sonarRT render engine
#  Blender built-in version, for plug and play
#

import bpy
import numpy as np
from mathutils import Vector
from math import sqrt, acos, cos, asin
import math

### math #######################################################################
# Function to append to a position
def append_to_position(A, i, j, k):
    if (i, j) not in A:
        A[(i, j)] = []
    A[(i, j)].append(k)    
    
def find_continuous_subsequences(seq):
    subsequences = []
    current_subsequence = [seq[0]]

    for i in range(1, len(seq)):
        if seq[i] == seq[i-1] + 1:
            current_subsequence.append(seq[i])
        else:
            subsequences.append(current_subsequence)
            current_subsequence = [seq[i]]
    
    subsequences.append(current_subsequence)
    return subsequences

def find_medians(subsequences):
    medians = []
    for subseq in subsequences:
        if len(subseq) % 2 == 1:
            medians.append(subseq[len(subseq)//2])
        else:
            mid_index = len(subseq)//2
            medians.append(subseq[mid_index])
    return medians

# generate image without anti-aliasing
def ac_generate(dis,img,uplimit,lowlimit,resolution):
    
    length=np.floor((uplimit-lowlimit)/resolution)
    length=int(length)
    
    imageheight, imagewidth = dis.shape[0], dis.shape[1]
    
    count=np.zeros((length,imagewidth))
    raw=np.zeros((length,imagewidth))
    for j in range(imagewidth):
        for i in range(imageheight):
            dp0=np.floor((dis[i,j]-lowlimit)/resolution)
            dp=int(dp0)
        ## maximum integration: 3 times
            if dp>=length or dp<=0:
                continue
            if count[dp,j]<2:
                raw[dp,j]=img[i,j]+raw[dp,j]
                count[dp,j]=count[dp,j]+1
    return raw

#generate image with anti-aliasing
#for over-sampling
# undersampling can be allievated by inceasing the sampling number
def ac_generate_aa(dis,img,uplimit,lowlimit,resolution):
    
    length=np.floor((uplimit-lowlimit)/resolution)
    length=int(length)
    
    imageheight, imagewidth = dis.shape[0], dis.shape[1]
    raw=np.zeros((length,imagewidth))
    A={}
    
    for j in range(imagewidth):
        for i in range(imageheight):
            dp0=np.floor((dis[i,j]-lowlimit)/resolution)
            dp=int(dp0)
            if dp>=length or dp<=0:
                continue
            append_to_position(A, dp, j, i)
    
    count=np.zeros((length,imagewidth))        
    for key in A:
        sequence = A[key[0],key[1]]
        subsequences = find_continuous_subsequences(sequence)
        medians = find_medians(subsequences)
        
        for j in range(len(medians)):
            if count[key[0],key[1]]<2:
                raw[key[0],key[1]]+=img[medians[j],key[1]]
                #raw[key[0],key[1]]=np.max([img[medians[j],key[1]],raw[key[0],key[1]]])
                count[key[0],key[1]]+=1
            
    return raw

# record hit location for flow generation
def ac_generate_hitloc(dis,hitloc,uplimit,lowlimit,resolution):
    
    length=np.floor((uplimit-lowlimit)/resolution)
    length=int(length)
    
    imageheight, imagewidth = dis.shape[0], dis.shape[1]
    
    count=np.zeros((length,imagewidth))

    raw=np.zeros((length,imagewidth,4))
    for j in range(imagewidth):
        for i in (range(imageheight)):
            dp0=np.floor((dis[i,j]-lowlimit)/resolution)
            dp=int(dp0)
        ## maximum integration: 3 times
            if dp>=length or dp<=0:
                continue
            if count[dp,j]<1:
                raw[dp,j,0:3]=hitloc[i,j]
                count[dp,j]=count[dp,j]+1
                #container[dp,j]=int(i)
    count[count < 0.01] = 0
    count[count >= 0.01] = 1
    raw[:,:,3] = count
    return raw

def ac_generate_aa_hitloc(dis,hitloc,uplimit,lowlimit,resolution):
    
    length=np.floor((uplimit-lowlimit)/resolution)
    length=int(length)
    
    imageheight, imagewidth = dis.shape[0], dis.shape[1]
    raw=np.zeros((length,imagewidth,4))
    A={}
    
    for j in range(imagewidth):
        for i in (range(imageheight)):
            dp0=np.floor((dis[i,j]-lowlimit)/resolution)
            dp=int(dp0)
        ## maximum integration: 3 times
            if dp>=length or dp<=0:
                continue
            append_to_position(A, dp, j, i)
            
    count=np.zeros((length,imagewidth))        
    for key in A:
        sequence = A[key[0],key[1]]
        subsequences = find_continuous_subsequences(sequence)
        medians = find_medians(subsequences)
        for j in range(len(medians)):
            if count[key[0],key[1]]<1:
                raw[key[0],key[1],0:3]=hitloc[medians[j],key[1]]
                count[key[0],key[1]]+=1
    # mask = count#.copy()
    count[count < 0.01] = 0
    count[count >= 0.01] = 1
    raw[:,:,3] = count
    #print(np.max(count))
       
    return raw

#add crosstalk in an emprical way
def add_crosstalk(raw,scene):
    
    length, imagewidth = raw.shape[0], raw.shape[1]
    binary = raw.copy()
    
    cross = raw.copy()
    count=np.zeros((length,imagewidth))   
    for i in range(int(length)):
        for j in range(imagewidth):
            if binary[i,j] > scene.sonarRT.cross_talk_threshold: #3.0
                for m in range(imagewidth): #imagewidth
                    if count[i,m]<2 and m%16 >= (j%16)-4 and m%16 < (j%16)+4:
                        l = i+np.random.randint(0,2)
                        if l>length-1:
                            continue
                        cross[l,m] = cross[l,m]+0.5*raw[i,j]
                        count[l,m] = count[l,m]+1
                break
                
    return cross

# Function to transform a single point from world to camera
def transform_point(point,camera_matrix):
    
    H = np.array(camera_matrix)
    R = H[0:3,0:3]
    T = H[0:3,3]
    T = T[:,np.newaxis]
    point = point[:,np.newaxis]
    point = R.transpose()@(point-T)
    
    return point[:,0]

def blender_coordinates_to_sonar(data):
    """
    note that blender has a very special type of coordinate definition
    make it fit our definition of sonar coordinates
    """
    sonar_coord = np.zeros(3)
    sonar_coord[1] = data[0]
    sonar_coord[2] = data[1]
    sonar_coord[0] = -data[2]
    
    return sonar_coord

# ================ ray casting ========================================
"""
ray casting from here
"""

def ray_cast(scene, origin, direction):
    """wrapper around Blender's Scene.ray_cast() API

    Parameters
    ----------
    scene ： bpy.types.Scene
        The Blender scene we will cast a ray in
    origin : Vector, float array of 3 items
        Origin of the ray
    direction : Vector, float array of 3 items
        Direction of the ray

    Returns
    -------
    has_hit : bool
        The result of the ray cast, i.e. if the ray hits anything in the scene
    hit_loc : Vector, float array of 3 items
        The hit location of this ray cast
    hit_norm : Vector, float array of 3 items
        The face normal at the ray cast hit location
    index : int
        The face index of the hit face of the hit object
        -1 when original data isn’t available
    hit_obj : bpy_types.Object
        The hit object
    matrix: Matrix, float 4 * 4
        The matrix_world of the hit object
    """
    return scene.ray_cast(scene.view_layers[0].depsgraph, origin, direction)


def RT_trace_ray(scene, ray_orig, ray_dir, lights, y, x, buf_dist, buf_c, buf_light, buf_hitloc, buf_br, depth):
    """Cast a single ray into the scene

    Parameters
    ----------
    scene : bpy.types.Scene
        The scene that will be rendered
        It stores information about the camera, lights, objects, and material
    ray_orig : Vector, float array of 3 items
        Origin of the current ray
    ray_dir : Vector, float array of 3 items
        Direction of the current ray
    lights : list of bpy_types.Object
        The list of lights in the scene
    depth: int
        The recursion depth of raytracing
        i.e. the number that light bounces in the scene

    Returns
    -------
    color : Vector, float array of 3 items
        Color of the pixel
    """

    # First, we cast a ray into the scene using Blender's built-in function
    has_hit, hit_loc, hit_norm, index, hit_obj, _ = ray_cast(scene, ray_orig, ray_dir)

    # set initial color (black) for the pixel
    color = np.zeros(3)
    
    # if the ray hits nothing in the scene
    # return black
    if not has_hit:
        return color
    # save the distance during ray tracing
    dist = np.linalg.norm(hit_loc-ray_orig)
    buf_dist[y,x,depth] = dist
    
    buf_hitloc[y,x,:] = np.array(hit_loc)
    
    # ray_cast returns the surface normal of the object geometry
    # this normal may be facing the other way when the ray origin is inside the object
    # here we flip the normal if its wrong, and populate the ray_is_inside variable
    # which will be handy when calculating transmission direction
    ray_inside_object = False
    if hit_norm.dot(ray_dir) > 0:
        hit_norm = -hit_norm
        ray_inside_object = True

    # get the ambient color of the scene
    # generally set to zero
    ambient_color = scene.sonarRT.ambient_color

    # get the material of the object we hit
    mat = hit_obj.sonarRT_material

    # extract the diffuse and specular colors from the material
    # since we only need RGB instead of RGBA,
    # we use .xyz to extract the first three component of the color vector
    diffuse_color = Vector(mat.diffuse_color).xyz
   
    specular_color = Vector(mat.specular_color).xyz
    # get specular hardness
    specular_hardness = mat.specular_hardness

    # iterate through all the lights in the scene
    hit_by_light = False
    for light in lights:
        # get light color
        light_color = np.array(
            light.data.sonarRT_light.color * light.data.sonarRT_light.energy
        )

        # ----------
        # TODO 1: Shadow Ray
        #
        # Read the lines of code above to see the variables that are already there, e.g. hit_loc.
        #
        # we first cast a shadow ray from the hit location to the light
        # to see if the hit location is in shadow
        #
        # first, calculate the vector from hit location to the light: light_vec
        # the location of the light can be accessed through light.location
        light_vec = light.location - hit_loc  # replace the right hand side
        light_dist = np.linalg.norm(light_vec)
        buf_light[y,x,depth]=light_dist
        # then we normalize light_vec to get the light direction: light_dir
        light_dir = light_vec.normalized()  # do not change
        #
        # next, calculate the origin of the shadow ray: new_orig
        # raise shadow ray loc by small Epsilon in direction of normal to avoid self-occlusion
        new_orig = hit_loc + ((0.0001)*hit_norm)  # replace the right hand side
        #
        # cast the shadow ray from hit location to the light
        has_light_hit, _, _, _, _, _ = ray_cast(
            scene, new_orig, light_dir
        )  # do not change
        #
        # re-run this script, and render the scene to check your result with checkpoint 1
        # if you see black pixels, recall how we solve self-occlusion in lecture 5
        # ----------

        # if we hit something we are in the shadow of the light
        # so this light will have no contribution to the color
        if has_light_hit:
            continue
        
        hit_by_light = True
        # otherwise, we shade with Blinn-Phong model:
        # I = I_diffuse + I_specular
        #       I_diffuse: diffuse component
        #       I_specular: specular component
        #
        # The diffuse component can be calculated as:
        # I_diffuse = k_diffuse * I_light * (light_dir dot normal_dir)
        #       k_diffuse: intensity of diffuse component, in our case diffuse_color
        #       I_light: intensity of the light, light_color attenuated by inverse-square law
        #       light_dir: direction from the surface point to the light, in our case light_dir
        #       normal_dir: normal at the point on the surface, in our case hit_norm
        #
        # The specular component can be calculated as:
        # I_specular = k_specular * I_light
        #              * (normal_dir dot half_vector)^power
        #       k_specular: intensity of specular component, in our case specular_color
        #       I_light: same as above
        #       normal_dir: same as above
        #       half_vector: halfway vector between the view direction and light direction
        #       power: in our case specular_hardness
        # where:
        #       half_vector = the normalized vector of light_dir + view_dir
        #           light_dir: same as above
        #           view_dir: direction from the surface point to the viewer, the negative of ray_dir
        # ----------
        # TODO 2.1: Blinn-Phong Shading -- Diffuse
        #
        # calculate intensity of the light: I_light. 
        cos_theta = (light_dir.normalized()).dot(hit_norm.normalized())
        if(cos_theta>0):
            
            #light_fall_off = 1 / light_color_vec.length_squared() # todo inverse square law or theta?
            # light falloff
            mag = np.linalg.norm(light_vec)
            if scene.sonarRT.beam_pattern:
                hit_xyz_world = np.array(hit_loc)
                cam = bpy.data.objects['Camera']
                camera_matrix = cam.matrix_world.normalized()
                hit_xyz_camera = transform_point(hit_xyz_world,camera_matrix)
                hit_xyz_camera = blender_coordinates_to_sonar(hit_xyz_camera)
            
                theta = math.atan(hit_xyz_camera[1] /hit_xyz_camera[0])/math.pi*180
    
                phi = math.atan(hit_xyz_camera[2]/(math.sqrt(hit_xyz_camera[1]**2+hit_xyz_camera[0]**2)))/math.pi*180
               
                I_light = Vector(light_color / (4*mag * mag* 10**(1.95*mag/10))).xyz
                #I_light = Vector(light_color / (4*mag * mag)).xyz
            
                p = [-1.06918728e-4,-5.35605386e-2,5.82826912e-2,6.75185881e1]
                theta_fit = np.polyval(p, theta)
                #I_light = Vector(10**(y_fit/10)*I_light).xyz
                
                #p = [4.97166706e-3, -2.11091230e-1,-7.84929935e-1,6.64225790e1]
                #y_fit = np.polyval(p, phi)
                def func_flipped(xx):
                    xx_flipped = -xx
                    yy = 20.4888 - 0.936997 * xx_flipped
                    yy += 15.292815029004723 * np.maximum(xx_flipped - (-11.420296358910722), 0)
                    yy += -14.21586437270254 * np.maximum(xx_flipped - (-9.220090847589859), 0)
                    yy += -10.161563652458653 * np.maximum(xx_flipped - 8.98036814380006, 0)
                    yy += 10.076706863208734 * np.maximum(xx_flipped - 10.351841371812725, 0)
                    return yy
                def func(xx):
                    yy = 20.4888-0.936997*xx
                    yy += 15.292815029004723 * np.maximum(xx - (-11.420296358910722), 0)
                    yy += -14.21586437270254 * np.maximum(xx - (-9.220090847589859), 0)
                    yy += -10.161563652458653 * np.maximum(xx - 7.98036814380006, 0)
                    yy += 10.076706863208734 * np.maximum(xx - 10.351841371812725, 0)
                    return yy
                phi_fit = func(phi)
                y_fit = theta_fit*phi_fit/65
                I_light = Vector(10**(y_fit/10)*I_light).xyz
                
            else:
                I_light = Vector(light_color / (4*mag * mag* 10**(1.95*mag/10))).xyz
                I_light = Vector(10**(65/10)*I_light).xyz
         
            # calculate diffuse component, add that to the pixel color
            I_diffuse = diffuse_color * I_light * cos_theta**2
            color += I_diffuse  # replace this line
            buf_c[y,x,depth] = I_diffuse[0]*((1.0)**(1-depth))
            back_reflectivity = mat.back_reflectivity
            buf_br[y,x,depth] = back_reflectivity

        #
        # re-run this script, and render the scene to check your result with checkpoint 2.1
        # ----------
        # TODO 2.2: Blinn-Phong Shading -- Specular
        #
            with_specular = False
            if with_specular:
                # calculate half_vector
                half_vector = ((light_dir.normalized() + ray_orig.normalized())*0.5).normalized()
                # calculate specular component, add that to the pixel color
                I_specular = specular_color * I_light * pow(hit_norm.dot(half_vector), specular_hardness)
                color += I_specular
                buf_c[y,x,depth] += I_specular[0]
        # re-run this script, and render the scene to check your result with checkpoint 2.2
        # ----------

    # ----------
    # TODO 3: AMBIENT
    #
    # if none of the lights hit the object, add the ambient component I_ambient to the pixel color
    # else, pass here
    #
    # I_ambient = k_diffuse * k_ambient
    #
    # you might also need to add code elsewhere to make this work
    # e.g. you'll need to find a way to determine whether the object got hit by any of the lights above
    #
    # re-run this script, and render the scene to check your result with checkpoint 3
    # ----------
    if not hit_by_light:
        I_ambient = diffuse_color * Vector(ambient_color).xyz
        color += I_ambient

    # ----------
    # TODO 5: FRESNEL
    #
    # if don't use fresnel, get reflectivity k_r directly
    reflectivity = mat.mirror_reflectivity
    # otherwise, calculate k_r using schlick’s approximation
    n1 = 1
    n2 = mat.ior
    if ray_inside_object:
        n1 = mat.ior
        n2 = 1
        
    if mat.use_fresnel:
        # calculate R_0: R_0 = ((n1 - n2) / (n1 + n2))^2
        # Here n1 is the IOR of air, so n1 = 1
        # n2 is the IOR of the object, you can read it from the material property using: mat.ior
        #
        # calculate reflectivity k_r = R_0 + (1 - R_0) (1 - cos(theta))^5
        # theta is the incident angle. Refer to lecture 6 for definition
        R_0 = ((n1 - n2)/(n1 + n2))**2
        incident_angle = ray_dir.normalized().dot(hit_norm.normalized())
        reflectivity = R_0 + (1 - R_0) * (1 - cos(incident_angle))**5 # reflectivity 
    
    #
    # re-run this script, and render the scene to check your result with checkpoint 5
    # you won't see the effects of this until TODO 4 is also done
    # ----------

    # ----------
    # TODO 4: RECURSION
    #
    # mirror reflection -> trace
    #
    # if depth > 0, cast a reflected ray from current intersection point
    # with direction D_reflect to get the color contribution of the ray L_reflect
    # multiply L_reflect with reflectivity k_r, and add the result to the pixel color
    #
    # Equation for D_reflect is on lecture 6 slides
    # Reflectivity k_r has been already declared in TODO 5 above
    #
    # just like casting a shadow ray, we need to take care of self-occlusion here
    # remember to update depth
    #
    # re-run this script, and render the scene to check your result with checkpoint 4
    # ----------
    if depth > 0:
        # cast ray from hit pointcos
        if reflectivity>0:
            epsilon = (0.001 * hit_norm.normalized())
            origin = hit_loc + epsilon
        
            D_reflect = ray_dir.normalized() - 2 * ray_dir.normalized().dot(hit_norm.normalized()) * hit_norm.normalized()
        
            L_reflect = RT_trace_ray(scene, origin, D_reflect, lights, y, x, buf_dist, buf_c, buf_light, buf_hitloc, buf_br, depth-1)
        
            L_reflect *= reflectivity
            color += L_reflect 

    
    return color*1e-4

def RT_render_scene(scene, width, height, depth, buf):
    """Main function for rendering the scene

    Parameters
    ----------
    scene : bpy.types.Scene
        The scene that will be rendered
        It stores information about the camera, lights, objects, and material
    width : int
        Width of the rendered image
    height : int
        Height of the rendered image
    depth : int
        The recursion depth of raytracing
        i.e. the number that light bounces in the scene
    buf: numpy.ndarray
        the buffer that will be populated to store the calculated color
        for each pixel
    """
    m = 0
    yield m
    # define buffers
    buf_dist = np.zeros((height, width, depth+1))  # distance from view to hit
    buf_c = np.zeros((height, width, depth+1))  # shading
    buf_light = np.zeros((height, width, depth+1))  # distance from hit to light
    buf_hitloc = np.zeros((height, width, 3))
    buf_br = np.zeros((height, width, depth+1)) 

    # get all the lights from the scene
    scene_lights = [o for o in scene.objects if o.type == "LIGHT"]

    # get the location and orientation of the active camera
    cam_location = scene.camera.location
    cam_orientation = scene.camera.rotation_euler

    # get camera focal length
    focal_length = scene.camera.data.lens / scene.camera.data.sensor_width
    aspect_ratio = height / width

    # iterate through all the pixels, cast a ray for each pixel
    for y in range(height):
        # get screen space coordinate for y
        if y==int(height/3):
            m = 1
            yield m
        if y==int(height/3*2):
            m = 2
            yield m
        screen_y = ((y - (height / 2)) / height) * aspect_ratio/scene.render.pixel_aspect_x
        for x in range(width):
            # get screen space coordinate for x
            screen_x = (x - (width / 2)) / width
            # calculate the ray direction
            ray_dir = Vector((screen_x, screen_y, -focal_length))
            
            ray_dir.rotate(cam_orientation)
            ray_dir = ray_dir.normalized()
            # populate the RGB component of the buffer with ray tracing result
            buf[y, x, 0:3] = RT_trace_ray(
                scene, cam_location, ray_dir, scene_lights, y, x, buf_dist,buf_c, buf_light, buf_hitloc, buf_br,depth
            )
            # populate the alpha component of the buffer
            # to make the pixel not transparent
            buf[y, x, 3] = 1
            
            
    m=3 
    yield m 
    # height, width, depth
    cum_dist = np.zeros_like(buf_dist)
    height, width = buf_dist.shape[0], buf_dist.shape[1]
    #noise = np.random.uniform(-0.06, 0.06, (height, width,depth))
    mask = np.where(buf_dist > 0.01, 1, 0)
    if scene.sonarRT.range_diffuse:
        mu = scene.sonarRT.rd_mu # mean
        sigma = scene.sonarRT.rd_sigma  # standard deviation
    
        # Generate Gaussian distributed noise
        noise = np.random.normal(mu, sigma, (height, width, depth+1))*mask
    else:
        noise = np.zeros((height, width, depth+1))
    
    buf_dist_clean = buf_dist.copy()
    cum_dist_clean  = np.zeros_like(buf_dist_clean )
    for i in range(depth+1):
        
        buf_dist[:,:,i] = buf_dist[:,:,i]+noise[:,:,i]*mask[:,:,i]
        cum_dist[:,:,i] = np.sum(buf_dist[:,:,i:], axis=2)*mask[:,:,i]
        cum_dist_clean[:,:,i] = np.sum(buf_dist_clean[:,:,i:], axis=2)*mask[:,:,i]
        buf_light[:,:,i] = buf_light[:,:,i]*mask[:,:,i]
    
    
    ray_path_wrt = (cum_dist+buf_light)/2
    ray_c = buf_c  
    
    ray_path_wrt = np.flipud(ray_path_wrt).copy()
    ray_c = np.flipud(ray_c).copy()
    
    ray_path_prt = cum_dist
    ray_path_prt = np.flipud(ray_path_prt).copy()
    
    if scene.sonarRT.flow:
        hitloc = np.flipud(buf_hitloc).copy()
        cum_dist_clean = np.flipud(cum_dist_clean).copy()
    
    uplimit=scene.sonarRT.up_limit #4.336
    lowlimit=scene.sonarRT.low_limit #4.336
    resolution=scene.sonarRT.res
    length=np.floor((uplimit-lowlimit)/resolution)
    length=int(length)
    
    imageheight, imagewidth = ray_c.shape[0], ray_c.shape[1]
    
    if scene.sonarRT.flow:
        raw_hitloc=ac_generate_hitloc(cum_dist_clean[:,:,depth],hitloc,uplimit,lowlimit,resolution)
        
    raw_list = []
    
    for i in range(depth+1- 1, -1, -1):
        if i == depth+1- 1-1:
            ray_c[0:20,:,i] = ray_c[0:20,:,i]
            #ray_c[20:50,:,i] = ray_c[20:50,:,i]*100
        raw = ac_generate_aa(ray_path_wrt[:,:,i],ray_c[:,:,i],uplimit,lowlimit,resolution)
        raw_list.append(raw)
        if i == depth+1- 1-1:
            #ray_c[0:20,:,i] = ray_c[0:20,:,i]/1000
            #ray_c[20:50,:,i] = ray_c[20:50,:,i]/100
            ray_c[:,:,i] = ray_c[:,:,i]/2
        print("ray_c:",np.max(ray_c[:,:,i]))
        from PIL import Image
        #path = Image.fromarray(np.clip(raw/np.max(raw)*255,0,255).astype(np.uint8), 'L') 
        #path.save("E:/sim-data-journal/sim-label/tester"+str(i+10)+".png")
        
        
    for i in range(depth- 1, -1, -1): #ray_c[:,:,depth]
        if i==depth-2:
            ray_c[:,:,i]=ray_c[:,:,i]/20
        raw = ac_generate_aa(ray_path_prt[:,:,i],ray_c[:,:,i],uplimit,lowlimit,resolution)
        raw_list.append(raw)
        from PIL import Image
        #path = Image.fromarray(np.clip(ray_path_prt[:,:,i]/np.max(ray_path_prt[:,:,i])*255,0,255).astype(np.uint8), 'L') 
        #path.save("E:/sim-data-journal/sim-label/test0.png")
        
        #path = Image.fromarray(np.clip(raw/np.max(raw)*255,0,255).astype(np.uint8), 'L') 
        #path.save("E:/sim-data-journal/sim-label/test"+str(i+10)+".png")
        
        
        
    sum_image = np.zeros_like(raw, dtype=np.float32)
    
    for img in raw_list:
        mask = np.where(sum_image < 1.0, 1, 0)
        sum_image = sum_image + img#*mask
    
    # poisson noise
    noise_scale = 0.01
    noise = np.random.poisson(noise_scale, sum_image.shape)
    
    # Generate Rayleigh noise
    scale =5.0  # Scale parameter for the Rayleigh distribution, adjust as needed
    rayleigh_noise = np.random.rayleigh(scale, sum_image.shape)
    # Clip the values to be within 0 to 5
    rayleigh_noise = np.clip(rayleigh_noise, 0, 10)
    sum_image = sum_image#+noise
    print("raw:",np.max(sum_image))
    if scene.sonarRT.cross_talk:
        cross = add_crosstalk(sum_image,scene)
    else:
        cross = sum_image
    
    cross = cross#+rayleigh_noise
    cross_norm = cross
    
    #cross_norm = np.clip(cross/scene.sonarRT.norm*255,0,255).astype(np.uint8)
    
    cross_norm = 20*np.log10(cross_norm/1000+1)
    cross_norm = cross_norm+rayleigh_noise
    print("log max:",np.max(cross_norm))

    def resize_nearest_neighbor(img, new_height, new_width):
        old_height, old_width = img.shape
        row_scale = old_height / new_height
        col_scale = old_width / new_width

        # Create row and column index grids
        row_idx = (np.arange(new_height) * row_scale).astype(int)
        col_idx = (np.arange(new_width) * col_scale).astype(int)

        # Clamp index values (to avoid index out of bounds)
        row_idx = np.clip(row_idx, 0, old_height - 1)
        col_idx = np.clip(col_idx, 0, old_width - 1)

        # Build output using broadcasting
        resized_img = img[row_idx[:, None], col_idx]
        return resized_img

    # Normalize and clip
    cross_norm = np.clip(cross_norm / scene.sonarRT.norm * 255, 0, 255).astype(np.uint8)

    # Resize to (1333, 128)
    resized_image = resize_nearest_neighbor(cross_norm, 1333, 128)

    # Save if needed (save as raw .npy or text format)
    if scene.sonarRT.save_path is not None:
        np.save(scene.sonarRT.save_path, resized_image)  # Can replace with np.savetxt for .txt

    # Save hit locations
    if scene.sonarRT.flow:
        np.save(scene.sonarRT.hitloc_path, raw_hitloc)

    # Resize to (height, width)
    cross_norm_resize = resize_nearest_neighbor(cross_norm, height, width)   
    
    # Rotate 180 degrees using numpy
    cross_norm_resize = np.rot90(cross_norm_resize, 2)  # rotate 180 degrees
    cross_norm_resize = np.fliplr(cross_norm_resize)
    # Blender automatically add gamma correction, need to remove this
    # for saving image, no such problem
    def srgb_to_linear(x):
        x = np.clip(x, 0.0, 1.0)
        return np.where(
            x <= 0.04045,
            x / 12.92,
            ((x + 0.055) / 1.055) ** 2.4
        )
    buf[:, :, 0] = srgb_to_linear(cross_norm_resize/255)
    buf[:, :, 1] = srgb_to_linear(cross_norm_resize/255)
    buf[:, :, 2] = srgb_to_linear(cross_norm_resize/255)
    buf[:, :, 3] = np.ones((height,width))
        
    m = 4
    yield m
    
    return buf


# modified from https://docs.blender.org/api/current/bpy.types.RenderEngine.html
class SonarRTRenderEngine(bpy.types.RenderEngine):
    # These three members are used by blender to set up the
    # RenderEngine; define its internal name, visible name and capabilities.
    bl_idname = "sonar_RT"
    bl_label = "SonarRT"
    bl_use_preview = False

    # Init is called whenever a new render engine instance is created. Multiple
    # instances may exist at the same time, for example for a viewport and final
    # render.
    def __init__(self):
        self.draw_data = None

    # When the render engine instance is destroy, this is called. Clean up any
    # render engine data here, for example stopping running render threads.
    def __del__(self):
        pass

    # This is the method called by Blender for both final renders (F12) and
    # small preview for materials, world and lights.
    def render(self, depsgraph):
        scene = depsgraph.scene
        scale = scene.render.resolution_percentage / 100.0
        self.size_x = int(scene.render.resolution_x * scale)
        self.size_y = int(scene.render.resolution_y * scale)

        if self.is_preview:
            pass
        else:
            self.render_scene(scene)

    def render_scene(self, scene):
        
        # create a buffer to store the calculated intensities
        # buffer is has four channels: Red, Green, Blue, and Alpha
        # default is set to (0, 0, 0, 0), which means black and fully transparent
        height, width = self.size_y, self.size_x
        
        buf = np.zeros((height, width, 4))  # RGBA
        
        # empty image in the window
        result = self.begin_result(0, 0, self.size_x, self.size_y*2)
        layer = result.layers[0].passes["Combined"]

        # get the maximum ray tracing recursion depth
        depth = scene.sonarRT.recursion_depth
        
        uplimit=scene.sonarRT.up_limit #4.336
        lowlimit=scene.sonarRT.low_limit #4.336
        resolution=scene.sonarRT.res
        length=np.floor((uplimit-lowlimit)/resolution)
        length=int(length)
        
        
        # time the render
        import time
        from datetime import timedelta

        start_time = time.time()

        # start ray tracing
        for m in RT_render_scene(scene,width, height, depth, buf):


            # update Blender progress bar
            self.update_progress(m / 4)

            # update render result
            # update too frequently will significantly slow down the rendering
            if m == 4:
                self.update_result(result)
                layer.rect = buf.reshape(-1, 4).tolist()

            # catch "ESC" event to cancel the render
            if self.test_break():
                break
        # tell Blender all pixels have been set and are final
        self.end_result(result)
        

def register():
    bpy.utils.register_class(SonarRTRenderEngine)


def unregister():
    bpy.utils.unregister_class(SonarRTRenderEngine)


