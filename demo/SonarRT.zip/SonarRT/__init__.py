bl_info = {
    "name": "Sonar Ray Tracer",
    "description": "Custom sonar ray tracing engine with UI",
    "author": "Yusheng Wang",
    "version": (0, 0, 2020),
    "blender": (2, 90, 0),
    "category": "Render"
}

import bpy
from . import sonarRT_plugin
from . import sonarRT_UIpanels

def register():
    sonarRT_plugin.register()
    sonarRT_UIpanels.register()

def unregister():
    sonarRT_plugin.unregister()
    sonarRT_UIpanels.unregister()

if __name__ == "__main__":
    register()