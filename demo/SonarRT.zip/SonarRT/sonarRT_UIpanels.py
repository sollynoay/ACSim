#  sonarRT_panel.py
#
#  Support file for sonarRT render engine.
#
#  Create custom properties and UI panels for
#  easy access to rendering related parameters.

import bpy

# Custom Properties for SonarRT materials
class ObjectSettings(bpy.types.PropertyGroup):
    diffuse_color: bpy.props.FloatVectorProperty(
        default=(0.78, 0.78, 0.78), subtype="COLOR"
    )
    specular_color: bpy.props.FloatVectorProperty(
        default=(0.2, 0.2, 0.2), subtype="COLOR"
    )
    specular_hardness: bpy.props.FloatProperty(default=1000.0, soft_min=0.0)
    use_fresnel: bpy.props.BoolProperty(default=False)
    mirror_reflectivity: bpy.props.FloatProperty(
        default=0.0, soft_min=0.0, soft_max=1.0
    )
    back_reflectivity: bpy.props.FloatProperty(
        default=1.0, soft_min=0.0, soft_max=1.0
    )
    ior: bpy.props.FloatProperty(default=1.450)
    transmission: bpy.props.FloatProperty(default=0.0, soft_min=0.0, soft_max=1.0)


# Custom Properties for SonarRT lights
class LightSettings(bpy.types.PropertyGroup):
    color: bpy.props.FloatVectorProperty(default=(1.0, 1.0, 1.0), subtype="COLOR")
    energy: bpy.props.FloatProperty(default=10.0)


# Custom Properties for SonarRT renderer
class RenderSettings(bpy.types.PropertyGroup):
    recursion_depth: bpy.props.IntProperty(default=2, soft_min=0)
    ambient_color: bpy.props.FloatVectorProperty(
        default=(0.00, 0.00, 0.00), subtype="COLOR"
    )
    up_limit: bpy.props.FloatProperty(default=5.0, soft_max=10.0)
    low_limit: bpy.props.FloatProperty(default=1.0, soft_min=0.0, soft_max=10.0)
    res: bpy.props.FloatProperty(default=0.003, soft_min=0.0)
    norm: bpy.props.FloatProperty(default=60.0, soft_min=0.01)
    cross_talk: bpy.props.BoolProperty(default=False)
    cross_talk_threshold: bpy.props.FloatProperty(default=3.0, soft_min=0.0)
    range_diffuse: bpy.props.BoolProperty(default=False)
    rd_mu: bpy.props.FloatProperty(default=0.0, soft_min=0.0)
    rd_sigma: bpy.props.FloatProperty(default=0.01, soft_min=0.0)
    beam_pattern: bpy.props.BoolProperty(default=False)
    
    save_path: bpy.props.StringProperty(
        name="Save Path",
        description="Define the save path for image outputs",
        default="",
        maxlen=1024,
        subtype='FILE_PATH'  # Use 'DIR_PATH' if you want a directory path
    )
    
    flow: bpy.props.BoolProperty(default=False)
    
    hitloc_path: bpy.props.StringProperty(
        name="Save Path",
        description="Define the save path for hitloc outputs",
        default="",
        maxlen=1024,
        subtype='FILE_PATH'  # Use 'DIR_PATH' if you want a directory path
    )



# SonarRT material panel
class SonarRTMaterialPanel(bpy.types.Panel):
    bl_label = "SonarRT Material"
    bl_idname = "OBJECT_PT_sonarRT_material"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "material"

    @classmethod
    def poll(cls, context):
        return context.scene.render.engine == "sonar_RT"

    def draw(self, context):
        mat = context.object.sonarRT_material

        split = self.layout.split(factor=0.4)
        col_1 = split.column()
        col_2 = split.column()
        col_1.alignment = "RIGHT"

        col_1.label(text="Diffuse Color")
        col_2.prop(mat, "diffuse_color", text="")
        col_1.label(text="Specular Color")
        col_2.prop(mat, "specular_color", text="")
        col_1.label(text="Specular Hardness")
        col_2.prop(mat, "specular_hardness", text="")
        col_1.label(text="Fresnel")
        col_2.prop(mat, "use_fresnel", text="")

        col_1.label(text="Reflectivity")
        row = col_2.row()
        row.prop(mat, "mirror_reflectivity", text="")
        row.active = not mat.use_fresnel
        col_1.label(text="IOR")
        col_2.prop(mat, "ior", text="")

        col_1.label(text="transmission")
        col_2.prop(mat, "transmission", text="")
        
        col_1.label(text="Back reflectivity")
        row = col_2.row()
        row.prop(mat, "back_reflectivity", text="")


# SonarRT light panel
class SonarRTLightPanel(bpy.types.Panel):
    bl_label = "SonarRT Light"
    bl_idname = "OBJECT_DATA_PT_sonarRT_light"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"

    @classmethod
    def poll(cls, context):
        return (
            context.scene.render.engine == "sonar_RT"
            and context.object.type == "LIGHT"
        )

    def draw(self, context):
        lt = context.light.sonarRT_light

        split = self.layout.split(factor=0.4)
        col_1 = split.column()
        col_2 = split.column()
        col_1.alignment = "RIGHT"

        col_1.label(text="Color")
        col_1.label(text="Power")
        col_2.prop(lt, "color", text="")
        col_2.prop(lt, "energy", text="")


# SonarRT camera panel
class SonarRTCameraPanel(bpy.types.Panel):
    bl_label = "SonarRT Camera"
    bl_idname = "OBJECT_DATA_PT_sonarRT_camera"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "data"

    @classmethod
    def poll(cls, context):
        return (
            context.scene.render.engine == "sonar_RT"
            and context.object.type == "CAMERA"
        )

    def draw(self, context):
        cam = context.camera

        split = self.layout.split(factor=0.4)
        col_1 = split.column()
        col_2 = split.column()
        col_1.alignment = "RIGHT"

        col_1.label(text="Focal Length")
        col_1.label(text="Sensor Fit")
        col_1.label(text="Size")
        col_2.prop(cam, "lens", text="")
        col_2.prop(cam, "sensor_fit", text="")
        col_2.prop(cam, "sensor_width", text="")


# SonarRT output panel
class SonarRTDimensionsPanel(bpy.types.Panel):
    bl_label = "SonarRT Dimensions"
    bl_idname = "OUTPUT_PT_sonarRT_dimension"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "output"

    @classmethod
    def poll(cls, context):
        return context.scene.render.engine == "sonar_RT"

    def draw(self, context):
        rd = context.scene.render

        split = self.layout.split(factor=0.4)
        col_1 = split.column()
        col_2 = split.column(align=True)
        col_1.alignment = "RIGHT"

        col_1.label(text="Resolution X")
        col_1.label(text="Y")
        col_1.label(text="%")
        col_1.label(text="Aspect X")
        col_1.label(text="Y")
        
        col_2.prop(rd, "resolution_x", text="")
        col_2.prop(rd, "resolution_y", text="")
        col_2.prop(rd, "resolution_percentage", text="")
        
        col_2.prop(rd, "pixel_aspect_x", text="")
        col_2.prop(rd, "pixel_aspect_y", text="")


# SonarRT render settings panel
class SonarRTRenderPanel(bpy.types.Panel):
    bl_label = "SonarRT Render Settings"
    bl_idname = "RENDER_PT_sonarRT_render"
    bl_space_type = "PROPERTIES"
    bl_region_type = "WINDOW"
    bl_context = "render"

    @classmethod
    def poll(cls, context):
        return context.scene.render.engine == "sonar_RT"

    def draw(self, context):
        sc = context.scene.sonarRT

        split = self.layout.split(factor=0.4)
        col_1 = split.column()
        col_2 = split.column()
        col_1.alignment = "RIGHT"

        col_1.label(text="depth")
        col_1.label(text="ambient")
        col_1.label(text="Sonar uplimit")
        col_1.label(text="lowlimit")
        col_1.label(text="Range resolution")
        col_2.prop(sc, "recursion_depth", text="")
        col_2.prop(sc, "ambient_color", text="")
        col_2.prop(sc, "up_limit", text="")
        col_2.prop(sc, "low_limit", text="")
        col_2.prop(sc, "res", text="")
        col_1.label(text="Normalize")
        col_2.prop(sc, "norm", text="")
        
        col_1.label(text="Cross talk")
        col_2.prop(sc, "cross_talk", text="")
        
        col_1.label(text="Cross talk threshold")
        row = col_2.row()
        row.prop(sc, "cross_talk_threshold", text="")
        row.active = sc.cross_talk
        
        col_1.label(text="Range diffusion")
        col_2.prop(sc, "range_diffuse", text="")
        
        col_1.label(text="mu")
        row = col_2.row()
        row.prop(sc, "rd_mu", text="")
        row.active = sc.range_diffuse
        
        col_1.label(text="sigma")
        row = col_2.row()
        row.prop(sc, "rd_sigma", text="")
        row.active = sc.range_diffuse
        
        col_1.label(text="Save path")
        col_2.prop(sc, "save_path", text="")
        
        col_1.label(text="Flow")
        col_2.prop(sc, "flow", text="")
        
        col_1.label(text="Save hitloc path")
        row = col_2.row()
        row.prop(sc, "hitloc_path", text="")
        row.active = sc.flow
        
        col_1.label(text="Beam pattern")
        col_2.prop(sc, "beam_pattern", text="")


def register():
    # register custom properties
    bpy.utils.register_class(ObjectSettings)
    bpy.utils.register_class(LightSettings)
    bpy.utils.register_class(RenderSettings)
    # register panels
    bpy.utils.register_class(SonarRTMaterialPanel)
    bpy.utils.register_class(SonarRTLightPanel)
    bpy.utils.register_class(SonarRTCameraPanel)
    bpy.utils.register_class(SonarRTDimensionsPanel)
    bpy.utils.register_class(SonarRTRenderPanel)
    # add custom properties to existing types
    bpy.types.Scene.sonarRT = bpy.props.PointerProperty(type=RenderSettings)
    bpy.types.Object.sonarRT_material = bpy.props.PointerProperty(type=ObjectSettings)
    bpy.types.PointLight.sonarRT_light = bpy.props.PointerProperty(type=LightSettings)


def unregister():
    # unregister custom properties
    bpy.utils.unregister_class(ObjectSettings)
    bpy.utils.unregister_class(LightSettings)
    bpy.utils.unregister_class(RenderSettings)
    #bpy.utils.unregister_class(SonarSettings)
    # unregister panels
    bpy.utils.unregister_class(SonarRTMaterialPanel)
    bpy.utils.unregister_class(SonarRTLightPanel)
    bpy.utils.unregister_class(SonarRTCameraPanel)
    bpy.utils.unregister_class(SonarRTDimensionsPanel)
    bpy.utils.unregister_class(SonarRTRenderPanel)